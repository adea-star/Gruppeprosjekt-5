
        /*Legger ordene i en liste*/
        const ordene = ["baker", "isbre", "farge", "lyset", "smile", "venne", "bilde", "aktør", "blant", "drama",
            "binde", "matte", "grave", "sjakk", "treet", "stort", "skole", "extra", "rekke", "klage",
            "dvale", "plass", "håper", "skala", "radio", "jager", "drage", "ovner", "vifte", "krone",
            "klokt", "fjern", "pakke", "smart", "drift", "låner", "kaste", "ferde", "juble", "vrake",
            "frukt", "trene", "eldre", "gylde", "fyker", "havne", "myter", "gjære", "gjest", "yngre",
            "blodt", "rubin", "kaste", "vokse", "lyder", "spise", "sende", "kjole", "skyte", "telle",
            "korte", "frisk", "skilt", "gråte", "blume", "haler", "snekk", "pride", "snart", "troll",
            "rulle", "veien", "skape", "kappe", "hoppe", "lytte", "stine", "smake", "snepe", "skade",
            "kaste", "felle", "støtt", "lense", "felle", "grise", "flate", "damen", "melle",
            "søker", "skift", "skuff", "finns", "skutt", "alger", "reise", "skeis",
            "skudd", "rente", "smått", "smalt", "brent", "klapp", "glans", "fløte",
            "kurve", "ynger", "stive", "skinne", "kratt", "blikk", "kikke", "verne", "varde",
            "kjapp", "bøtte", "drepe", "hoppe", "pluss", "stein", "plage", "skudd",
            "svele", "tanke", "skrin", "jeger", "valgt", "trett", "bløte", "utvik", "skinn", "gilde",
            "vårer", "flere", "kropp", "verv", "plått", "drikk", "glatt", "høyre",
            "takke", "skape", "brakt", "spank", "skikk", "gjemt", "klake", "slott",
            "balje", "fluer", "skive", "kjole", "avbit", "laste", "knekt", "sving",
            "perle", "værer", "sanne", "fjord", "skrap", "dreit", "bombe", 
            "stand",  "skjev",  "blokk", "slipt", "slake", "flate", "skjel",
            "flott", "nyhet", "knall", "hette",
            "krapp", "skamb", "skarf", "styre", 
            "skinn","tavle", "skift", "drepe","skalk",
            "klatt", "skarp", "liten", "blikk", "kaldt", "skrei", 
            "alene", "alibi", "andre", "arbeid", 
            "arisk", "atlas", "avise", "avkast", "bader", 
            "baken", "baker", "baner", "banke", "baren", "barna", "benke", "berus", 
            "bilde", "binds", "biter", "blikk", "bliss", "blond", "blåse", "bluss", 
            "boker", "bolle", "bombe", "borer", "borte", "brake", "brans", "brann", "brase", "brist", 
            "broer", "brose", "brudd", "bruke", "brukt", "buler", "bytte", "cafea", "citar", "clash", 
            "direk", "dorte", "drage", "drakk", "drama", "dreng", "drive", "dyktig", "dette", "duell", 
            "duett", "dyret", "dyser", "effekt", "eksel", "eklen", "eller", "enkel", "enhet", 
            "etnis", "evnen", "ferie", "feste", "fiask", "fiken", "final", "fiske", "flere", "flint", 
            "folie", "forse", "forte", "forts", "frost", "frukt", "fugee", "fugle", "fugle", "fyren", 
            "galne", "garbe", "garde", "gevin", "gevin", "gjelt", "gjøre", "grasp", "grett", "grens", 
            "grene", "gripe", "grunn", "grønn", "grunn", "gulne", "habib", "hager", "hakk", "hange", 
            "hasse", "heike", "helge", "hilde", "hoved", "håper", "huset", "hynse", "høyre", "hytte", 
            "inter", "jakt", "jager", "jalle", "kalte", "kamera", "karer", "karen", "kapse", "kilde", 
            "kilef", "kors", "klappe", "kler", "klare", "klute", "knall", "knelt", "knute", "koer", 
            "kolle", "korre", "korte", "korts", "kuse", "kåpen", "laike", "lager", "laste", "later", 
            "levee", "letts", "lyset", "lyser", "lysere", "lørne", "liten", "liten", "makle", "maner", 
            "marker", "mamma", "mange", "menke", "merke", "merit", "modig", "mulig", "muler", "muse", 
            "muse", "mutter", "møte", "møte", "mørkt", "myte", "norsk", "nasje", "nevn", "normal", 
            "nomin", "nøtte", "nårte", "null", "nikte", "nyhet", "olje", "odde", "oldeb", "onkel", 
            "opple", "opple", "oppe", "parke", "part", "perle", "pose", "pride", "pris", "profi", 
            "rike", "ringe", "ratt", "remse", "runde", "rulle", "ruten", "renne", "reise", "rente", 
            "reste", "ros", "ramme", "raus","rakst", "ruke", "ruta", "rull", "rider", 
            "siste", "skive", "skrem", "seier", "sikkert", "skrap", "stjap", "start", "tart", 
            "terse", "tette", "turt", "tekn", "tilsk", "utry", "vinst", "våk", "vild", "zlie"
    
            ];
    
            let gjeldendeOrd = ordene[Math.floor(Math.random() * ordene.length)]; // Velger et tilfeldig ord fra arrayet 'ordene' 
            let gjeldendeRad = 0; // Setter den gjeldende raden 0
            let gjeldendeRute = 0; // Setter den gjeldende ruten  0
    
            const spilleBrett = document.getElementById('spille-brettet'); // Henter HTML-elementet med id 
            const tastaturet = document.getElementById('tastaturet'); // Henter HTML-elementet med id 
    
            /*Lager et rutenett 5*5 for gjettningene (5forsøk)*/
            function lagBrett() {
                for (let i = 0; i < 5; i++) {  /*5 rader som tilsvarerforsøkene til brukeren*/ 
                    for (let j = 0; j < 5; j++) {  /*5 kolonner for at det er 5 bokstaver i ordet*/
                        const rute = document.createElement('div'); // Lager et nytt 'div'-element som representerer en rute 
                        rute.classList.add('rute'); // Legger til CSS-klassen 
                        rute.setAttribute('data-rad', i); // Setter en data-attributt 'data-rad' 
                        rute.setAttribute('data-rute', j); // Setter en data-attributt 'data-rute' 
                        
                        const span = document.createElement('span');             // Lager et nytt 'span'-element
                        rute.appendChild(span);  // Legger 'span'-elementet 
                        
                        spilleBrett.appendChild(rute); // Legger 'rute'-elementet som barn
                    }
                }
            }
    
            /*Lager tastaturet, inkludert æ,ø,å og en enter tast*/ 
            function lagTastatur() {
                const keys = "ABCDEFGHIJKLMNOPQRSTUVWXYZÆØÅ"; // Definerer en streng med alle bokstaver i alfabetet 
                keys.split('').forEach(key => { // Deler opp strengen til et array 
                    const keyElement = document.createElement('div'); // Lager et nytt 'div'-element 
                    keyElement.classList.add('key'); // Legger til CSS-klassen 
                    keyElement.textContent = key; // Setter tekstinnholdet 
                    keyElement.setAttribute('data-key', key.toLowerCase()); // Setter en data-attributt 
                    keyElement.addEventListener('click', () => handleKeyPress({ key: key })); // Legger til en event listener 
                    tastaturet.appendChild(keyElement);  // Legger 'keyElement' 
                });
    
                /*Enter-tasten*/
                const enterKey = document.createElement('div'); // Lager et nytt 'div'-element 
                enterKey.classList.add('key'); // Legger til CSS-klassen 
                enterKey.textContent = "Enter"; // Setter tekstinnholdet 
                enterKey.setAttribute('data-key', 'enter'); // Setter data-attributten 
                enterKey.addEventListener('click', () => sendGjett()); // Legger til en event listener 
                tastaturet.appendChild(enterKey); // Legger 'enterKey' 
            }
    
            /*Gjør at man kan trykke på tastene*/
            function handleKeyPress(event) {
                let key = event.key.toUpperCase(); // Henter tastetrykket og store bokstav
    // Sjekker om tasten som ble trykket er "Enter".
                if (key === "ENTER") {
                    if (gjeldendeRute === 5) sendGjett(); /*Funker kun når raden er fylt ut*/
                } else if (key === "BACKSPACE") { // Sjekker om tasten som ble trykket er "Backspace"
                    if (gjeldendeRute > 0) { // Sjekker om det er noen bokstaver å slette 
                        gjeldendeRute--;
                        const rute = document.querySelector(`[data-rad='${gjeldendeRad}'][data-rute='${gjeldendeRute}'] span`);
                        rute.textContent = ""; // Fjerner innholdet 
                    }
                } else if (/^[A-ZÆØÅ]$/.test(key) && gjeldendeRute < 5) { // Sjekker om tasten er en gyldig bokstav 
                    const rute = document.querySelector(`[data-rad='${gjeldendeRad}'][data-rute='${gjeldendeRute}'] span`);
                    rute.textContent = key; // Setter inn bokstaven 
                    gjeldendeRute++; // Øker gjeldendeRute 
                }
            }
    
            /*Sjekker om ordet er gyldig*/
            function erGyldigOrd(word) {
                return ordene.includes(word);
            }
    
            /*Sender inn gjetningen*/
            function sendGjett() {
                const guess = Array.from(document.querySelectorAll(`[data-rad='${gjeldendeRad}'] span`))
                    .map(rute => rute.textContent.toLowerCase()) // Gjør bokstavene små.
                    .join(''); // Setter sammen bokstavene til et ord.
    
                if (guess.length < 5) return; // Hvis ordet er kortere enn 5 bokstaver
    
                // Sjekk om ordet finnes i ordlisten
                if (!erGyldigOrd(guess)) {
                    alert("Ordet du skrev, er ikke et gyldig ord, prøv igjen.");
                    return;
                }
    
                for (let i = 0; i < 5; i++) { // Går gjennom hver bokstav i gjettet ord 
                    const rute = document.querySelector(`[data-rad='${gjeldendeRad}'][data-rute='${i}']`);
                    const keyElement = document.querySelector(`[data-key='${guess[i]}']`); 
                    const bokstav = guess[i];   // Lagrer den gjettede bokstaven i en variabel.
    
                    if (bokstav === gjeldendeOrd[i]) {
                        rute.classList.add('correct');
                        keyElement.classList.add('green'); // Hvis bokstaven er korrekt 
                    } else if (gjeldendeOrd.includes(bokstav)) {
                        rute.classList.add('present');
                        keyElement.classList.add('yellow'); // Hvis bokstaven finnes i ordet, 
                    } else {
                        rute.classList.add('absent');
                        keyElement.classList.add('gray'); // Hvis bokstaven ikke finnes i ordet
                    }
                }
    
                if (guess === gjeldendeOrd) {
                    alert("Du gjettet ordet! Gratulerer! Du blir sendt til vinner-siden.");
                    window.location.href = 'vinner.html';     // Hvis gjettet ord er likt det riktige ordet, 
                } else if (gjeldendeRad === 4) { // 5. forsøk
                    alert(`Du tapte, ordet var "${gjeldendeOrd}". Prøv igjen`);
                    location.reload(); // Hvis alle 5 forsøk er brukt 
                } else {
                    gjeldendeRad++;
                    gjeldendeRute = 0;     // Hvis ordet ikke ble gjettet og det er flere forsøk igjen
                }
            }
    
            /*Starter spillet*/
            lagBrett();
            lagTastatur();
    
            // Legger til en hendelseslytter for tastetrykk 
            document.addEventListener('keydown', handleKeyPress);