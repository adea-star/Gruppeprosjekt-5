
const canvas = document.getElementById('spillCanvas'); // Henter canvas-elementet
const ctx = canvas.getContext('2d'); // Får tilgang til 2D-grafikkonteksten 
const textInput = document.getElementById('ordene'); // Henter tekstfeltet for spillerens input
const infoDisplay = document.getElementById('infoOversikt'); // Henter elementet som viser spillinformasjon 
const velgValgene = document.getElementById('velgValgene'); // Henter elementet som inneholder valgknapper
const spillOversikt = document.getElementById('spillOversikt'); // Henter containeren for spillvisning
const sluttSkjerm = document.getElementById('slutt-skjerm'); // Henter slutt-skjermen
const igjenButton = document.getElementById('igjenButton'); // Henter knappen
const nesteLink = document.getElementById('nesteLink'); // Henter lenken som fører 

let ord = []; // Initialiserer en tom liste (array) for ordene som skal vises
let poeng = 0; // Setter spillerens startpoeng til 0
let liv = 3; // Setter antall liv spilleren har ved spillets start til 3
let animationFrame;
let kodeOrdene = [
"html", "css", "javascript", "div", "span", 
"header", "footer", "section", "form", "input", 
"button", "style", "class", "id", "link", 
"flex", "grid", "transition", "animation", "hover", 
"eventListener" ]; // En liste med kode-relaterte ord som spilleren må skrive inn
let spillHastighet = 1; // Setter startverdien for spillets hastighet

// Funksjon for å starte spillet med spesifisert vanskelighetsgrad
function startSpill(vanskelighetsgrad) {
    velgValgene.style.display = 'none'; // Skjuler valgskjermen når spillet starter
    spillOversikt.style.display = 'flex'; // Viser spillområdet på skjermen
    if (vanskelighetsgrad === 'vanskelig') { // Sjekker om spilleren har valgt den vanskelige graden
        liv = 1; // Setter spillerens liv til 1 
        spillHastighet = 3; // Øker spillhastigheten for raskere fall 
    } else { // Hvis spilleren velger en enklere vanskelighetsgrad
        liv = 3; // Setter spillerens liv til 3
        spillHastighet = 1; // Setter spillhastigheten til normal
    }
    begynnSpill(); // Starter spillet ved å kalle `begynnSpill`-funksjonen
} 

// Funksjon for å starte spillet
function begynnSpill() {
    ord = []; // Tømmer listen med ord, slik at nye ord kan legges til når spillet begynner
    poeng = 0; // Setter poengsummen til 0 når spillet starter på nytt
    infoDisplay.innerHTML = `<h2>Lives: ${liv} | Score: ${poeng}</h2>`; // Oppdaterer info-displayet for liv og poengsum
    giKodeOrdene(); // Kaller funksjonen som legger til nye kodeord 
    animationFrame = window.requestAnimationFrame(loop);  // Starter en kontinuerlig animasjon ved å kalle 'loop' funksjonen
}

// Definerer en klasse "Ordene" hvert ord i spillet
class Ordene {
    constructor(ordene, x) { //et nytt ord med spesifiserte verdier
        this.ordene = ordene; // Setter ordet som skal vises
        this.guessed = false; // Om ordet er gjettet
        this.x = x; // Setter startposisjonen på X-aksen for ordet
        this.y = 0; // Setter startposisjonen på Y-aksen
        this.bottom = false;  // Angir om ordet har nådd bunnen av skjermen
    }
// Funksjon for å tegne ordet på canvas
    tegn() {
        ctx.fillStyle = 'black'; // Setter fargen på teksten til svart
        ctx.font = '24px Arial'; // Setter fonten til 24px Arial
        ctx.fillText(this.ordene, this.x, this.y); // Tegner ordet på skjermen 
    }
// Funksjon for å bevege ordet nedover skjermen
    beveg() {
        this.y += spillHastighet; // Øker Y-posisjonen til ordet
        if (this.y > canvas.height) { // Sjekker om ordet har nådd bunnen
            this.bottom = true; // Setter 'bottom' til true hvis ordet er utenfor 
        }
    }
}
// Funksjon som sjekker brukerens input
function checkInput() {
    for (let i = 0; i < ord.length; i++) { // Loop gjennom alle ordene 
        if (textInput.value === ord[i].ordene) { // Sjekker om teksten som er skrevet i input-feltet matcher et ord i arrayet
            poeng++; // Øker poengsummen med 1
            ord.splice(i, 1); // Fjerner ordet fra arrayet "ord" 
            textInput.value = "";  // Tømmer input-feltet etter korrekt svar
            giKodeOrdene(); // Kaller på funksjonen som genererer nye ord
            break; // Bryter ut av løkken etter at et ord er gjettet korrekt
        }
    }

    if (poeng >= 15) { // Hvis poengsummen er 10 eller mer
        endGame('win'); // Kaller funksjonen endGame 'win' 
    }
}

// Funksjon for å generere et nytt kodeord
function giKodeOrdene() {
    if (kodeOrdene.length > 0) { // Sjekker om det finnes kodeord igjen i listen
        const wIndex = Math.floor(Math.random() * kodeOrdene.length);  // Velger et tilfeldig index fra "kodeOrdene" arrayet
        const randX = Math.floor(Math.random() * (canvas.width - 100)); // Genererer en tilfeldig X-koordinat
        const ordene = new Ordene(kodeOrdene[wIndex], randX); // Lager et nytt "Ord" objekt med tilfeldig valgt ord 
        ord.push(ordene); // Legger det nye ordet til "ord" arrayet 
        kodeOrdene.splice(wIndex, 1); // Fjerner det valgte ordet fra "kodeOrdene"
    }
}

function endGame(result) {
    cancelAnimationFrame(animationFrame); // Stopper pågående animasjon
    spillOversikt.style.display = 'none'; // Skjuler spillområdet
    sluttSkjerm.style.display = 'flex';  // Vist slutt-skjermen

    if (result === 'lose') { // Hvis spilleren har tapt
        document.getElementById('slutt-beskjed').textContent = 'Du rakk ikke å skrive alle ordene prøv igjen! ';
        igjenButton.style.display = 'block'; // Vist "Prøv igjen"-knappen
        nesteLink.style.display = 'none'; // Skjuler "Gå videre"-linken
        igjenButton.onclick = () => location.reload(); // Når "Prøv igjen"-knappen 
    } else if (result === 'win') {
        document.getElementById('slutt-beskjed').textContent = 'Gratulerer! Du klarte å håndtere ordene som faller.';
        igjenButton.style.display = 'none'; // Gjemmer retry button
        nesteLink.style.display = 'none'; // Gjemmer next page link

        // 3 delay til typing.html
        setTimeout(() => {
            window.location.href = 'universe.html'; // Redirect to typing.html 
        }, 2000); // 3-second delay
    }
}

function loop() {
        // Tømmer canvas før hvert nytt bilde tegnes
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ord.forEach((o, index) => {     // Går gjennom alle ordene som er på canvaset
        o.tegn(); // Tegner ordet
        o.beveg(); // Beveger ordet nedover skjermen
        if (o.bottom) {         // Sjekker om ordet har nådd bunnen av skjermen
            liv--; // Minker liv med 1
            ord.splice(index, 1); // Fjerner ordet fra listen
            if (liv <= 0) {
                endGame('lose'); // Hvis ingen liv er igjen, avslutter spillet med tap
            }
        }
    });
// Når listen med ord er tom, og det fortsatt er flere ord i 'kodeOrdene'
    if (ord.length === 0 && kodeOrdene.length > 0) {
        giKodeOrdene(); // Legger til nye ord på skjermen
    }
// Oppdaterer informasjonen om liv og poeng på skjermen
    infoDisplay.innerHTML = `<h2>Lives: ${liv} | Score: ${poeng}</h2>`;
    animationFrame = window.requestAnimationFrame(loop);
}

//Det skriver i tekstboksen
textInput.addEventListener('input', checkInput);