const canvas = document.getElementById('spillCanvas'); // Henter referanse til canvas-elementet med id 
const ctx = canvas.getContext('2d'); // Henter 2D-tegningskonteksten til canvasen 
const infoDisplay = document.getElementById('infoOversikt'); // Henter referanse til div-en med id 
const velgValgene = document.getElementById('velgValgene'); // Henter referanse til div-en med id 
const spillOversikt = document.getElementById('spillOversikt');   // Henter referanse til div-en med id '
const sluttSkjerm = document.getElementById('slutt-skjerm');  // Henter referanse til div-en med id 
const igjenButton = document.getElementById('igjenButton');  // Henter referanse til knappen med id
const nesteLink = document.getElementById('nesteLink');  // Henter referanse til lenken med id 

let astronaut; // Definerer variabelen 'astronaut' 
let hindring = []; // Definerer en tom array 'hindring'
let poeng = 0; // Definerer variabelen 'poeng' som starter på 0
let liv; // Definerer variabelen 'liv'
let spillHastighet; // Definerer variabelen 'spillHastighet'
let spillFerdig = false; // Definerer variabelen 'spillFerdig

let spill = null; // Definerer variabelen 'spill' 

// Definerer en funksjon 'startSpill' 
function startSpill(vanskelighetsgrad) {
    velgValgene.style.display = 'none'; // Skjuler div-en med id 'velgValgene'
    spillOversikt.style.display = 'flex'; // Vist div-en med id 'spillOversikt' 

    if (vanskelighetsgrad === 'vanskelig') { // Sjekker om vanskelighetsgraden er 'vanskelig'
        liv = 1;         // Setter antall liv til 1 for vanskelig 
        spillHastighet = 3;   // Setter spillhastigheten til 3
    } else { // Hvis vanskelighetsgraden ikke er 'vanskelig
        liv = 3;   // Setter antall liv til 3
        spillHastighet = 1.5; // Setter spillhastigheten til 1 
    }
    begynnSpill(); // Kaller funksjonen 'begynnSpill' 
}

 // Definerer funksjonen 'begynnSpill' 
function begynnSpill() {
    astronaut = new Component(80, 40, "white", 500, 200, "image"); // Lager et nytt 'Component'-objekt 
    astronaut.image.src = "images/raket.png"; // Setter kildebildet
    poeng = 0; //Poengsummen til 0 ved spillets start
    hindring = []; // Tømmer arrayen 'hindring' 
    spillFerdig = false; // Setter spillFerdig til 'false'

    if (!spill) { // Sjekker om spill-variabelen er null 
        spill = {
            interval: setInterval(updateSpill, 20), // Initialiserer spill-objektet med nødvendige 
            frameNo: 0,   // Initialiserer ramme nummeret til 0
        };
    }

    window.addEventListener('keydown', bevegAstronaut); // Lytter etter 'keydown' (når en tast trykkes ned) 
    window.addEventListener('keyup', stopAstronaut);  // Lytter etter 'keyup' (når en tast slippes opp)
}

// Definerer en konstruktørfunksjon 'Component
function Component(width, height, color, x, y, type) {
    this.type = type; // Setter komponentens type 
    this.width = width; // Setter komponentens bredde
    this.height = height; // Setter komponentens høyde 
    this.x = x; // Setter komponentens horisontale posisjon 
    this.y = y;  // Setter komponentens vertikale posisjon
    this.speedX = 0; // Setter komponentens horisontale hastighet 
    this.speedY = 0; // Setter komponentens vertikale hastighet 

    if (type === "image") {
        this.image = new Image(); // Sjekker om komponentens type er 'image' 
    }

    // Definerer en metode 'update' 
    this.update = function() {
        if (this.type === "image" && this.image) { // Sjekker om komponentens type er 'image' 
            ctx.drawImage(this.image, this.x, this.y, this.width, this.height); // Hvis komponenten er et bilde, bruker 'drawImage' 
        } else {   // Hvis komponenten ikke er et bilde 
            ctx.fillStyle = color; // Setter fargen for å fylle 
            ctx.fillRect(this.x, this.y, this.width, this.height); // Tegner et rektangel på canvaset 
        }
    }

    this.nyPos = function() { // Definerer en metode 'nyPos' 
        this.x += this.speedX; // Oppdaterer komponentens horisontale posisjon 
        this.y += this.speedY * spillHastighet;     // Dette gjør at spillhastigheten kan justere hvor raskt
        this.treffHindring(); // Kaller 'treffHindring' 
    }

    this.treffHindring = function() { // Definerer en metode 'treffHindring
        const bottom = canvas.height - this.height; // Definerer variabelen 'bottom' 
        if (this.y > bottom) this.y = bottom; // Hvis komponentens y-posisjon er under bunnen av canvaset
        if (this.y < 0) this.y = 0; // Hvis komponentens y-posisjon er over toppen av canvaset
    }

    this.treffMed = function(otherobj) { // Definerer en metode 'treffMed' 
        const left = this.x; // Lagrer den venstre kanten 
        const right = this.x + this.width; // Lagrer den høyre kanten av komponenten 
        const top = this.y; // Lagrer den øvre kanten av komponenten 
        const bottom = this.y + this.height; // Lagrer den nedre kanten av komponenten 
        const otherLeft = otherobj.x;     // Lagrer den venstre kanten av det andre objektet
        const otherRight = otherobj.x + otherobj.width; // Lagrer den høyre kanten av det andre objektet
        const otherTop = otherobj.y; // Lagrer den øvre kanten av det andre objektet
        const otherBottom = otherobj.y + otherobj.height;     // Lagrer den nedre kanten av det andre objektet
        return !(bottom < otherTop || top > otherBottom || right < otherLeft || left > otherRight); // Sjekker om det er en kollisjon 
    }
}

function updateSpill() {
    if (spillFerdig) return; // Stopper funksjonen hvis spillet 

    for (let i = 0; i < hindring.length; i++) { // Sjekker hver hindring
        if (astronaut.treffMed(hindring[i])) { // Hvis astronauten treffer en hindring
            liv--; // Reduserer liv
            hindring.splice(i, 1); // Fjerner hindringen
            updateInformasjon(); // Oppdaterer informasjon

            if (liv <= 0) { // Hvis livene er tomme
                spillFerdig = true; // Setter spillet som ferdig
                clearInterval(spill.interval); // Stopper spillet
                document.getElementById('slutt-beskjed').textContent = 'Du klarte ikke å fly rundt i universet uten å treffe hindringene, prøv igjen!';
                sluttSkjerm.style.display = 'block';  // Vist slutt-skjermen
                igjenButton.style.display = 'block';  // Vist "Prøv igjen"-knapp
                nesteLink.style.display = 'none';  // Skjuler "Neste"-lenke
                canvas.style.display = 'none';  // Skjuler canvas
                igjenButton.onclick = () => location.reload();  // Last inn siden på nytt
                return;
            }
        }
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height); // Rydder canvaset

    spill.frameNo += 1; // Øker rammeantallet
    poeng = spill.frameNo; // Setter poeng til rammeantallet
    updateInformasjon(); // Oppdaterer informasjonen

    if (poeng >= 3000) { // Hvis poeng er 3000 eller mer
        spillFerdig = true; // Setter spillet som ferdig
        clearInterval(spill.interval); // Stopper spillet
        document.getElementById('slutt-beskjed').textContent = 'Gratulerer! Du klarte å fly i verdensrommet!';
        sluttSkjerm.style.display = 'block';  // Vist slutt-skjerm
        igjenButton.style.display = 'none';   // Skjuler "Prøv igjen"-knapp
        nesteLink.style.display = 'block'; // Vist "Neste"-lenke
        canvas.style.display = 'none';  // Skjuler canvas
        setTimeout(() => { 
            window.location.href = 'wordle.html';  // Går til neste spill etter 2 sekunder
        }, 2000); 
        return;
    }

    if (spill.frameNo === 1 || everyInterval(150)) { // Sjekker første ramme eller intervall
        const x = canvas.width; // Setter X-posisjon til høyre kant
        const minHoyde = 20; // Minimum høyde på hindring
        const maxHoyde = 200; // Maksimum høyde på hindring
        const height = Math.floor(Math.random() * (maxHoyde - minHoyde + 1) + minHoyde); // Genererer tilfeldig høyde
        const minGap = 50; // Minimum gap mellom hindringer
        const maxGap = 200; // Maksimum gap mellom hindringer
        const gap = Math.floor(Math.random() * (maxGap - minGap + 1) + minGap); // Genererer tilfeldig gap
        hindring.push(new Component(10, height, "white", x, 0)); // Legger til øvre hindring
        hindring.push(new Component(10, x - height - gap, "white", x, height + gap)); // Legger til nedre hindring
    }

    for (let i = 0; i < hindring.length; i++) { // Løper gjennom hindringene
        hindring[i].x -= 1; // Flytter hindringen til venstre
        hindring[i].update();
    }

    astronaut.nyPos();
    astronaut.update();
}

function everyInterval(n) { // Sjekker om intervallet har blitt delt n ganger
    if ((spill.frameNo / n) % 1 === 0) return true; // Returnerer true hvis 
    return false;  
}

function bevegAstronaut(e) { // Beveger astronauten med piltastene eller W/S
    if (e.keyCode == 38 || e.keyCode == 87) astronaut.speedY = -1; // Opp (piltast eller W)
    if (e.keyCode == 40 || e.keyCode == 83) astronaut.speedY = 1; // Ned (piltast eller S)
}

function stopAstronaut(e) { // Stopper astronautens bevegelse når tasten slippes
    if (e.keyCode == 38 || e.keyCode == 87 || e.keyCode == 40 || e.keyCode == 83) astronaut.speedY = 0;
}

function updateInformasjon() { // Oppdaterer poeng og liv på skjermen
    document.getElementById("poeng").textContent = poeng;
    document.getElementById("liv").textContent = liv;
}